Sehr geehrter DFN-Anwender,

die SSH Communication Security Corp., Helsinki und der DFN-Verein haben im Juni 2000 ein Memorandum  of Understanding (MoU) geschlossen
(http://www.dfn.de/presse/dfn-presse/pm00-06-05.html).

Im Rahmen dieses MoU duerfen die beiden beigefuegten Lizenzfiles fuer die Version 2.4.0 des Tools SSH Secure Shell von DFN-Anwendern zu
Zwecken von Wissenschaft und Forschung unentgeltlich eingesetzt werden.

Bei Rueckfragen wenden Sie sich bitte an die Mailadresse: dfn-ssh@dfn.de.