package tsp;

/*-------------------------------------------------------------------------*/
/*                                                                         */
/*                         Beleg - Neuronale Netze                         */
/*                                                                         */
/*                       TRAVELLING SALESMAN PROBLEM                       */
/*                  KOHONEN NETWORK (SELF ORGANIZING MAP)                  */
/*                                                                         */
/*                                                                         */
/*  Sven Boerner                                                           */
/*  98/041/02                                                              */
/*  htw9919                                                                */
/*                                                                         */
/*  file name:             TSP.java (Java Applet)                          */
/*                                                    					   */
/* 	modified by:														   */
/* 	Hans-Christian Heinz												   */
/* 	50425																   */
/* 	FIMN, HTWK Leipzig													   */
/*                      												   */
/*-------------------------------------------------------------------------*/

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Random;

/**
 * Class TSP is the applet itself describing the Travelling Salesman Problem
 */
public class TSP extends Applet implements ActionListener {
	private Color LightGrey = new Color(0xEEEEEE), DarkGrey = new Color(
			0xCCCCCC), White = new Color(0xFFFFFF),
			Black = new Color(0x000000), Red = new Color(0xFF0000);

	private int numberOfCities, numberOfNeurons;
	private int currentCycle, numberOfCycles;
	private double etamin, etamax;
	private double sigmin, sigmax;
	private double time = 0.0, length = 0.0;
	private int nextCity[], update;
	private long timeBegin, timeEnd;
	private double x[], y[], cities[];
	private double weightSom[], weightWinner[];
	private static Random r = new Random();
	private boolean isAnimated = false;
	private boolean doit = false;

	private Button bStart, bNewMap, bAnimation, bDefaultValues, bStartTest;
	private Label lEvery, lCycles, lNumberOfCycles, lNumberOfCities,
			lNumberOfNeurons, lCurrentCycle, lCurrentCycleValue, lEtamin,
			lEtamax, lSigmin, lSigmax, lTime, lTimeValue, lLength,
			lLengthValue;
	private TextField tUpdate, tCycles, tCities, tNeurons, tEtamin, tEtamax,
			tSigmin, tSigmax;

	private GO myAnimator;
	private Image zBuffer;
	private Thread findRoute = null;
	private int areaWidth, areaHeight;

	Graphics networkArea = this.getGraphics();
	DecimalFormat df = new DecimalFormat("0.000");

	private boolean waitFlag;

	void setDefaultUpdate() {
		this.update = 100;
	}

	void setDefaultNumberOfCities() {
		this.numberOfCities = 120;
	}

	void setDefaultNumberOfNeurons() {
		this.numberOfNeurons = 600;
	}

	void setDefaultNumberOfCycles() {
		this.numberOfCycles = 3000;
	}

	void setDefaultEtamin() {
		this.etamin = 0.3;
	}

	void setDefaultEtamax() {
		this.etamax = 0.7;
	}

	void setDefaultSigmin() {
		this.sigmin = 0.1;
	}

	void setDefaultSigmax() {
		this.sigmax = 50.;
	}

	/**
	 * Setting Default Values
	 */
	void setDefaultValues() {
		setDefaultUpdate();
		setDefaultNumberOfCities();
		setDefaultNumberOfNeurons();
		setDefaultNumberOfCycles();
		setDefaultEtamin();
		setDefaultEtamax();
		setDefaultSigmin();
		setDefaultSigmax();
	}

	/**
	 * Initializing the Kohonen Network
	 */
	void initKohonenNetwork() {
		int i;
		double angle;

		this.x = new double[this.numberOfCities];
		this.y = new double[this.numberOfCities];
		this.nextCity = new int[this.numberOfCities];
		this.cities = new double[2 * this.numberOfCities];
		this.weightSom = new double[2 * this.numberOfNeurons];
		this.weightWinner = new double[2 * this.numberOfNeurons];

		for (i = 0; i < this.numberOfCities; i++) {
			this.cities[2 * i] = Math.random();
			this.cities[2 * i + 1] = Math.random();
		}

		for (i = 0; i < this.numberOfCities; i++) {
			this.x[i] = this.cities[2 * i];
			this.y[i] = this.cities[2 * i + 1];
		}

		for (i = 0; i < this.numberOfNeurons; i++) {
			angle = Math.PI * 2.0 * i / this.numberOfNeurons;
			this.weightSom[2 * i] = 0.5 + Math.cos(angle) / 4;
			this.weightSom[2 * i + 1] = 0.5 + Math.sin(angle) / 4;
		}
		this.time = 0.0;
		this.length = 0.0;
	}

	/**
	 * Creates a new Probability List of the Cities
	 */
	void distributeCities(int n) {
		int i, j, k, m;
		for (i = n - 1; i > 0; i--) {
			j = TSP.r.nextInt(i + 1);
			k = this.nextCity[j];
			for (m = j; m < i; m++) {
				this.nextCity[m] = this.nextCity[m + 1];
			}
			this.nextCity[i] = k;
		}
	}

	/**
	 * Gets the Winner Neuron
	 */
	int winnerNeuron(int j) {
		int i, g = 0;
		double a, b, min, dif;
		for (i = 0, min = 1.0e+10; i < this.numberOfNeurons; i++) {
			a = this.x[j] - this.weightSom[2 * i];
			b = this.y[j] - this.weightSom[2 * i + 1];
			dif = a * a + b * b;
			if (dif < min) {
				min = dif;
				g = i;
			}
		}
		return g;
	}

	/**
	 * Gets the Distance between two Points
	 */
	double distance(int a, int b) {
		double deltaX, deltaY;

		deltaX = Math.abs(this.weightWinner[2 * a] - this.weightWinner[2 * b]);
		deltaY = Math.abs(this.weightWinner[2 * a + 1]
				- this.weightWinner[2 * b + 1]);

		return (Math.sqrt((deltaX * deltaX) + (deltaY * deltaY)));
	}

	/**
	 * Gets the Length of the Route
	 */
	double getLength() {
		double lengthOfRoute = 0.0;
		int k, l, m;
		for (k = 0, l = 0; k < this.numberOfNeurons - 1; k++) {
			m = k + 1;
			lengthOfRoute += distance(l, m);
			l = m;
			lengthOfRoute += distance(0, l);
		}
		return lengthOfRoute;
	}

	/**
	 * Lerning Section for the SOM Net
	 */
	void recalculateWeights() {
		int i, j, m, winner, nextIndex, neighbor;
		double h, eta, sig;

		for (i = 0; i < this.numberOfCities; i++) {
			this.nextCity[i] = i;
		}
		distributeCities(this.numberOfCities);
		this.currentCycle = 0;

		do {
			eta = this.etamax
					* Math.pow(this.etamin / this.etamax, this.currentCycle
							/ (double) this.numberOfCycles);
			sig = this.sigmax
					* Math.pow(this.sigmin / this.sigmax, this.currentCycle
							/ (double) this.numberOfCycles);
			neighbor = (int) sig;
			sig = 2 * sig * sig;

			nextIndex = (this.currentCycle % this.numberOfCities);
			j = this.nextCity[nextIndex];
			winner = winnerNeuron(j);

			for (i = -neighbor; i < neighbor; i++) {
				m = (winner + i) % this.numberOfNeurons;
				if (m < 0) {
					m = this.numberOfNeurons + m;
				}
				h = i * i / sig;
				if (h < 20.0) {
					h = Math.exp(-h);
				} else {
					h = 0.0;
				}

				this.weightSom[2 * m] += eta * h
						* (this.x[j] - this.weightSom[2 * m]);
				this.weightSom[2 * m + 1] += eta * h
						* (this.y[j] - this.weightSom[2 * m + 1]);
			}

			// update every n cycles
			if (this.currentCycle % this.update == 0) {
				if (this.isAnimated) {
					paint(this.networkArea);
				}
				this.lCurrentCycleValue.setText("" + this.currentCycle);
			}

			if (nextIndex == (this.numberOfCities - 1)) {
				distributeCities(this.numberOfCities);
			}
			this.currentCycle++;
		} while (this.currentCycle < this.numberOfCycles);

		this.lCurrentCycleValue.setText("" + this.currentCycle);
		netComplete();
	}

	/**
	 * Creates a Net with the Winner Neurons
	 */
	void netComplete() {
		int i, m, winner;
		winner = winnerNeuron(0);

		for (i = 0; i < this.numberOfNeurons; i++) {
			m = (winner + i) % this.numberOfNeurons;
			this.weightWinner[2 * i] = this.weightSom[2 * m];
			this.weightWinner[2 * i + 1] = this.weightSom[2 * m + 1];
			this.waitFlag = false;
		}
	}

	/**
	 * Calculates the arithmetic average of the distance between each city and
	 * it's nearest neuron and adjusts the average by multiplying it with a
	 * factor of 500 to make for an easier decision about the quality of a
	 * solution, <1 being a "good" solution (almost every city is a "hit") and a
	 * "bad" solution (at least one city was visibly missed). Beware that this
	 * factor is the product of experimentation, not hard math.
	 * 
	 * @author Hans-Christian Heinz
	 * @return
	 * @return double averageDistance
	 */

	private double calculateError() {
		// TODO blahblah
		double averageDistance = 0.0;
		double factor = 500.0;
		for (int i = 0; i < this.numberOfCities; i++) {
			double minDistance = 10000.0;
			for (int j = 0; j < this.numberOfNeurons; j++) {
				double deltaX, deltaY;
				double distance;

				deltaX = Math.abs(this.x[i] - this.weightWinner[2 * j]);
				deltaY = Math.abs(this.y[i] - this.weightWinner[2 * j + 1]);

				distance = (Math.sqrt((deltaX * deltaX) + (deltaY * deltaY)));
				if (distance < minDistance) {
					minDistance = distance;
				}
			}
			averageDistance += minDistance;
		}
		averageDistance = averageDistance / this.numberOfCities;
		return (averageDistance * factor);

	}

	/**
	 * Class for the Thread that paints the Connection between the Cities,
	 * implemented as inner class
	 */
	private class GO implements Runnable {
		// implementation of the run section
		@Override
		public void run() {
			if (TSP.this.doit) {
				recalculateWeights();
				paint(TSP.this.networkArea);
				TSP.this.findRoute = null;
			}
		}
	}

	@Override
	public void init() {
		setDefaultValues();
		initKohonenNetwork();

		setLayout(new BorderLayout());
		GridBagLayout gbl = new GridBagLayout();

		Panel northPanel = new Panel();
		northPanel.setLayout(gbl);
		northPanel.setBackground(this.White);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.insets = new Insets(2, 2, 2, 2);

		this.bStart = new Button("Start");
		this.bStart.addActionListener(this);
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.gridheight = 1;
		gbl.setConstraints(this.bStart, gbc);
		northPanel.add(this.bStart);

		this.bNewMap = new Button("New Map");
		this.bNewMap.addActionListener(this);
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.gridheight = 1;
		gbl.setConstraints(this.bNewMap, gbc);
		northPanel.add(this.bNewMap);

		/*
		 * this.bDefaultValues = new Button("Default Values");
		 * this.bDefaultValues.addActionListener(this); gbc.gridx = 4; gbc.gridy
		 * = 0; gbc.gridwidth = 3; gbc.gridheight = 1;
		 * gbl.setConstraints(this.bDefaultValues, gbc);
		 * northPanel.add(this.bDefaultValues);
		 */

		this.bStartTest = new Button("Start Test");
		this.bStartTest.addActionListener(this);
		gbc.gridx = 4;
		gbc.gridy = 0;
		gbc.gridwidth = 3;
		gbc.gridheight = 1;
		gbl.setConstraints(this.bStartTest, gbc);
		northPanel.add(this.bStartTest);

		this.bAnimation = new Button("With Animation");
		this.bAnimation.addActionListener(this);
		gbc.gridx = 4;
		gbc.gridy = 1;
		gbc.gridwidth = 3;
		gbc.gridheight = 1;
		gbl.setConstraints(this.bAnimation, gbc);
		northPanel.add(this.bAnimation);

		this.lNumberOfCities = new Label("Number of Cities:");
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lNumberOfCities, gbc);
		northPanel.add(this.lNumberOfCities);

		this.tCities = new TextField(Integer.toString(this.numberOfCities));
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.tCities, gbc);
		northPanel.add(this.tCities);

		this.lNumberOfNeurons = new Label("Number of Neurons:");
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lNumberOfNeurons, gbc);
		northPanel.add(this.lNumberOfNeurons);

		this.tNeurons = new TextField(Integer.toString(this.numberOfNeurons));
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.tNeurons, gbc);
		northPanel.add(this.tNeurons);

		this.lNumberOfCycles = new Label("Number of Cycles:");
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lNumberOfCycles, gbc);
		northPanel.add(this.lNumberOfCycles);

		this.tCycles = new TextField(Integer.toString(this.numberOfCycles));
		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.tCycles, gbc);
		northPanel.add(this.tCycles);

		this.lCurrentCycle = new Label("Current Cycle:");
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lCurrentCycle, gbc);
		northPanel.add(this.lCurrentCycle);

		this.lCurrentCycleValue = new Label(Integer.toString(this.currentCycle));
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lCurrentCycleValue, gbc);
		northPanel.add(this.lCurrentCycleValue);

		this.lEtamin = new Label("etamin: ", Label.RIGHT);
		gbc.gridx = 2;
		gbc.gridy = 1;
		gbl.setConstraints(this.lEtamin, gbc);
		northPanel.add(this.lEtamin);

		this.tEtamin = new TextField(Double.toString(this.etamin));
		gbc.gridx = 3;
		gbc.gridy = 1;
		gbl.setConstraints(this.tEtamin, gbc);
		northPanel.add(this.tEtamin);

		this.lEtamax = new Label("etamax:", Label.RIGHT);
		gbc.gridx = 2;
		gbc.gridy = 2;
		gbl.setConstraints(this.lEtamax, gbc);
		northPanel.add(this.lEtamax);

		this.tEtamax = new TextField(Double.toString(this.etamax));
		gbc.gridx = 3;
		gbc.gridy = 2;
		gbl.setConstraints(this.tEtamax, gbc);
		northPanel.add(this.tEtamax);

		this.lSigmin = new Label("sigmin: ", Label.RIGHT);
		gbc.gridx = 2;
		gbc.gridy = 3;
		gbl.setConstraints(this.lSigmin, gbc);
		northPanel.add(this.lSigmin);

		this.tSigmin = new TextField(Double.toString(this.sigmin));
		gbc.gridx = 3;
		gbc.gridy = 3;
		gbl.setConstraints(this.tSigmin, gbc);
		northPanel.add(this.tSigmin);

		this.lSigmax = new Label("sigmax:", Label.RIGHT);
		gbc.gridx = 2;
		gbc.gridy = 4;
		gbl.setConstraints(this.lSigmax, gbc);
		northPanel.add(this.lSigmax);

		this.tSigmax = new TextField(Double.toString(this.sigmax));
		gbc.gridx = 3;
		gbc.gridy = 4;
		gbl.setConstraints(this.tSigmax, gbc);
		northPanel.add(this.tSigmax);

		this.lEvery = new Label("Update every", Label.RIGHT);
		gbc.gridx = 4;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lEvery, gbc);
		northPanel.add(this.lEvery);

		this.tUpdate = new TextField("" + this.update);
		this.tUpdate.setEditable(false);
		gbc.gridx = 5;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.tUpdate, gbc);
		northPanel.add(this.tUpdate);

		this.lCycles = new Label("Cycles");
		gbc.gridx = 6;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lCycles, gbc);
		northPanel.add(this.lCycles);

		this.lTime = new Label("Time needed:", Label.RIGHT);
		gbc.gridx = 4;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lTime, gbc);
		northPanel.add(this.lTime);

		this.lTimeValue = new Label("" + this.df.format(this.time) + " s");
		gbc.gridx = 5;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lTimeValue, gbc);
		northPanel.add(this.lTimeValue);

		this.lLength = new Label("Route Length:", Label.RIGHT);
		gbc.gridx = 4;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lLength, gbc);
		northPanel.add(this.lLength);

		this.lLengthValue = new Label("" + this.df.format(this.length));
		gbc.gridx = 5;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbl.setConstraints(this.lLengthValue, gbc);
		northPanel.add(this.lLengthValue);

		add("North", northPanel);

		this.myAnimator = new GO();
	}

	/**
	 * Listening to Events like pressing a Button
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		int dummyCities = this.numberOfCities;
		int dummyNeurons = this.numberOfNeurons;

		String which = e.getActionCommand();

		try {
			this.etamin = Double.parseDouble(this.tEtamin.getText());
			this.etamax = Double.parseDouble(this.tEtamax.getText());
			this.sigmin = Double.parseDouble(this.tSigmin.getText());
			this.sigmax = Double.parseDouble(this.tSigmax.getText());

			this.update = Integer.parseInt(this.tUpdate.getText());
			this.numberOfCycles = Integer.parseInt(this.tCycles.getText());
			this.numberOfCities = Integer.parseInt(this.tCities.getText());
			this.numberOfNeurons = Integer.parseInt(this.tNeurons.getText());

			if ((this.etamin <= 0) || (this.etamin >= 1)) {
				setDefaultEtamin();
				this.tEtamin.setText("" + this.etamin);
			}
			if ((this.etamax <= 0) || (this.etamax >= 1)) {
				setDefaultEtamax();
				this.tEtamax.setText("" + this.etamax);
			}
			if (this.etamin > this.etamax) {
				setDefaultEtamin();
				setDefaultEtamax();
				this.tEtamin.setText("" + this.etamin);
				this.tEtamax.setText("" + this.etamax);
			}
			if (this.sigmin <= 0) {
				setDefaultSigmin();
				this.tSigmin.setText("" + this.sigmin);
			}
			if (this.sigmax <= 0) {
				setDefaultSigmax();
				this.tSigmax.setText("" + this.sigmax);
			}
			if (this.sigmin > this.sigmax) {
				setDefaultSigmin();
				setDefaultSigmax();
				this.tSigmin.setText("" + this.sigmin);
				this.tSigmax.setText("" + this.sigmax);
			}
			if ((this.numberOfCities < 1) || (this.numberOfCities > 1000)) {
				setDefaultNumberOfCities();
				this.tCities.setText("" + this.numberOfCities);
			}
			if ((this.numberOfNeurons < 1) || (this.numberOfNeurons > 100000)) {
				setDefaultNumberOfNeurons();
				this.tNeurons.setText("" + this.numberOfNeurons);
			}
			if ((this.numberOfCycles < 0) || (this.numberOfCycles > 100000)) {
				setDefaultNumberOfCycles();
				this.tCycles.setText("" + this.numberOfCycles);
			}
			if ((this.update < 1) || (this.update > this.numberOfCycles)) {
				this.update = this.numberOfCycles;
				this.tUpdate.setText("" + this.update);
			}
			if ((dummyCities != this.numberOfCities)
					|| (dummyNeurons != this.numberOfNeurons)) {
				initKohonenNetwork();
			}

			if (which.equals("Start Test")) {
				testRoutine();
			}

			if (which.equals("Start")) {
				this.doit = true;
				this.timeBegin = new Date().getTime();
				this.findRoute = new Thread(this.myAnimator);
				this.findRoute.start();
			}
			if (which.equals("New Map")) {
				this.doit = true;
				initKohonenNetwork();
				this.timeBegin = new Date().getTime();
				this.findRoute = new Thread(this.myAnimator);
				this.findRoute.start();
			}
		} catch (Exception te) {
			this.tEtamin.setText("" + this.etamin);
			this.tEtamax.setText("" + this.etamax);
			this.tSigmin.setText("" + this.sigmin);
			this.tSigmax.setText("" + this.sigmax);

			this.tUpdate.setText("" + this.update);
			this.tCycles.setText("" + this.numberOfCycles);
			this.tCities.setText("" + this.numberOfCities);
			this.tNeurons.setText("" + this.numberOfNeurons);

			System.out
					.println("wrong input - continue using default values...\n"
							+ te);
		}

		if (which.equals("With Animation")) {
			this.bAnimation.setLabel("Without Animation");
			this.isAnimated = true;
			this.tUpdate.setEditable(true);
		}

		if (which.equals("Without Animation")) {
			this.bAnimation.setLabel("With Animation");
			this.isAnimated = false;
			this.tUpdate.setEditable(false);
		}

		if (which.equals("Default Values")) {
			setDefaultValues();

			this.tEtamin.setText("" + this.etamin);
			this.tEtamax.setText("" + this.etamax);
			this.tSigmin.setText("" + this.sigmin);
			this.tSigmax.setText("" + this.sigmax);
			this.tUpdate.setText("" + this.update);
			this.tCycles.setText("" + this.numberOfCycles);
			this.tCities.setText("" + this.numberOfCities);
			this.tNeurons.setText("" + this.numberOfNeurons);

			initKohonenNetwork();
		}
	}

	/**
	 * Translates the x Values between 0 and 1 to the painting area
	 */
	private int translateToX(double dummy) {
		int w = this.getSize().width;
		return (int) (dummy * (w - 0.0) + 0.0);
	}

	/**
	 * Translates the y Values between 0 and 1 to the painting area
	 */
	private int translateToY(double dummy) {
		int h = this.getSize().height;
		return (int) (dummy * (h - 140.0) + 140.0);
	}

	/**
	 * Translates the x Values between 0 and 1 to the painting area (with a
	 * margin for the Cities)
	 */
	private int translateToXmargin(double dummy) {
		// cities shouldn't be located outside the painting area
		// that's why let them a margin of 4 pixels (radius) ...
		int w = this.getSize().width;
		return (int) (dummy * (w - 8.0) + 4.0);
	}

	/**
	 * Translates the y Values between 0 and 1 to the painting area (with a
	 * margin for the Cities)
	 */
	private int translateToYmargin(double dummy) {
		// cities shouldn't be located outside the painting area
		// that's why let them a margin of 4 pixels (radius) ...
		int h = this.getSize().height;
		return (int) (dummy * (h - 148.0) + 144.0);
	}

	/**
	 * Gives the Time needed to a Label
	 */
	void printTime() {
		this.timeEnd = new Date().getTime();
		this.time = (double) (this.timeEnd - this.timeBegin) / 1000;
		this.lTimeValue.setText("" + this.df.format(this.time) + " s");
	}

	/**
	 * Gives the Length to a Label
	 */
	void printLength() {
		this.lLengthValue.setText("" + this.df.format(getLength()));
	}

	/**
	 * Painting all the Cities
	 */
	public void drawCities(Graphics g) {
		for (int i = 0; i < this.numberOfCities; i++) {
			g.setColor(this.White);
			g.fillOval(translateToXmargin(this.x[i]) - 4,
					translateToYmargin(this.y[i]) - 4, 8, 8);
			g.setColor(this.Red);
			g.drawOval(translateToXmargin(this.x[i]) - 4,
					translateToYmargin(this.y[i]) - 4, 8, 8);

		}
	}

	/**
	 * Painting the Grid
	 */
	public void drawGrid(Graphics g) {
		for (double i = 0; i <= 1.0; i += (1.0 / 14.0)) {
			g.drawLine(translateToX(0.0), translateToY(i),
					translateToX(1.0) - 1, translateToY(i));
			g.drawLine(translateToX(i), translateToY(0.0), translateToX(i),
					translateToY(1.0) - 1);
		}
	}

	/**
	 * Draws my Path
	 */
	public void drawNetwork(Graphics g) {
		Dimension size = this.getSize();
		int w = size.width, h = size.height;

		// clean it up
		g.setColor(this.LightGrey);
		g.fillRect(0, 0, w, h);

		// draw my grid
		g.setColor(this.DarkGrey);
		drawGrid(g);

		g.setColor(this.Black);
		if (this.isAnimated) {
			for (int i = 0; i < this.numberOfNeurons - 1; i++) {
				g.drawLine(translateToXmargin(this.weightSom[2 * i]),
						translateToYmargin(this.weightSom[2 * i + 1]),
						translateToXmargin(this.weightSom[2 * i + 2]),
						translateToYmargin(this.weightSom[2 * i + 3]));
			}
			// avoid gaps in the "circle" when animated
			g.drawLine(
					translateToXmargin(this.weightSom[2 * this.numberOfNeurons - 2]),
					translateToYmargin(this.weightSom[2 * this.numberOfNeurons - 1]),
					translateToXmargin(this.weightSom[0]),
					translateToYmargin(this.weightSom[1]));

			if (this.currentCycle > 0) {
				printTime();
				printLength();
			}
		} else {
			for (int i = 0; i < this.numberOfNeurons - 1; i++) {
				g.drawLine(translateToXmargin(this.weightWinner[2 * i]),
						translateToYmargin(this.weightWinner[2 * i + 1]),
						translateToXmargin(this.weightWinner[2 * i + 2]),
						translateToYmargin(this.weightWinner[2 * i + 3]));
			}

			if (this.currentCycle > 0) {
				printTime();
				printLength();
			}
		}

		drawCities(g);
	}

	@Override
	public void paint(Graphics g) {
		Dimension size = this.getSize();
		int w = size.width, h = size.height;
		this.setBackground(this.White);

		if ((this.zBuffer == null)
				|| ((this.areaWidth != w) || (this.areaHeight != h))) {
			this.zBuffer = this.createImage(w, h);
			this.areaWidth = w;
			this.areaHeight = h;
		}

		Rectangle myRectangle = new Rectangle(translateToX(0), translateToY(0),
				translateToX(1.0), translateToY(1.0));

		Graphics imageBufferBack = this.zBuffer.getGraphics();
		imageBufferBack.clipRect(myRectangle.x, myRectangle.y,
				myRectangle.width, myRectangle.height);
		Graphics imageBufferFront = this.getGraphics();
		imageBufferFront.clipRect(myRectangle.x, myRectangle.y,
				myRectangle.width, myRectangle.height);

		drawNetwork(imageBufferBack);
		imageBufferFront.drawImage(this.zBuffer, 0, 0, this);

		// cleaning and finishing process, automatic garbage collection
		myRectangle = null;
		imageBufferBack = null;
		imageBufferFront = null;
		System.gc();
	}

	@Override
	public void start() {
		this.findRoute = new Thread(this.myAnimator);
		this.findRoute.start();
	}

	@Override
	public void stop() {
		this.findRoute = null;
	}

	public void testRoutine() {
		for (int numCycles = 1000; numCycles <= 100000; numCycles = numCycles * 2) {
			setNumberOfCycles(numCycles);
			System.out.println();
			System.out.println();
			System.out.println("Number of Cycles: " + numCycles);
			int numNeurons = 100;
			for (int numCities = 100; numCities <= 1000; numCities = numCities + 100) {
				double averageError = 0.0;
				boolean flag = true;
				int n = 1;

				setNumberOfCities(numCities);
				while (flag) {

					if ((numCities * 100 < numNeurons)) {
						numNeurons = numCities;
						break;
					}
					setNumberOfNeurons(numNeurons);
					averageError = 0;
					for (int i = 0; i < 10; i++) {
						this.waitFlag = true;
						initKohonenNetwork();
						this.doit = true;
						this.timeBegin = new Date().getTime();
						this.findRoute = new Thread(this.myAnimator);
						this.findRoute.start();
						while (this.waitFlag) {
						}
						;
						averageError += calculateError();
					}
					averageError = averageError / 10;
					System.out.println(numNeurons + " : " + averageError);

					if ((averageError < 1.1) && (averageError > 0.9)) {
						break;
					}
					if (averageError > 1) {
						numNeurons = (int) (numNeurons + numNeurons
								* (averageError / n));
					} else {
						numNeurons = (int) (numNeurons - numNeurons
								/ (averageError * n));
					}
					n++;
				}
				if (numCities == numNeurons) {
					System.out.println(numCities + " : not enough cycles");
					System.out.println();
					System.out.println("Continueing with more cycles");
					break;
				} else {
					System.out.println(numCities + " : " + numNeurons);
				}
			}
		}
	}

	private void setNumberOfNeurons(int numNeurons) {
		this.numberOfNeurons = numNeurons;
	}

	private void setNumberOfCities(int numCities) {
		this.numberOfCities = numCities;
	}

	private void setNumberOfCycles(int numCycles) {
		this.numberOfCycles = numCycles;

	}
}
